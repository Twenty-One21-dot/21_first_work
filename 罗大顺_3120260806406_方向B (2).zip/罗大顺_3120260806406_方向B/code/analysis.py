"""园区微电网风光储协调优化配置。

运行本文件会读取 data/ 下的三个原始 Excel，计算基础任务、拓展分析与双目标创新，
并把图表、results.md 和 analysis_results.json 写回项目目录。
"""

from __future__ import annotations

import json
import os
from calendar import monthrange
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib import font_manager
from scipy.optimize import linprog


ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
FIG_DIR = ROOT / "figures"
DT = 1.0

PARKS = {
    "A": {"pv_kw": 750.0, "wind_kw": 0.0, "max_load_kw": 447.0},
    "B": {"pv_kw": 0.0, "wind_kw": 1000.0, "max_load_kw": 419.0},
    "C": {"pv_kw": 600.0, "wind_kw": 500.0, "max_load_kw": 506.0},
}

GRID_PRICE = 1.0
PV_COST = 0.4
WIND_COST = 0.5
ETA_C = 0.95
ETA_D = 0.95
BATTERY_POWER = 50.0
BATTERY_ENERGY = 100.0
BATTERY_POWER_COST = 800.0
BATTERY_ENERGY_COST = 1800.0
BATTERY_LIFE_YEARS = 10.0
SOC_MIN_FRAC = 0.10
SOC_MAX_FRAC = 0.90


def configure_plot_font() -> None:
    candidates = [
        Path(os.environ.get("CJK_FONT", "__not_set__")),
        Path(r"C:\Windows\Fonts\msyh.ttc"),
        Path("/System/Library/Fonts/PingFang.ttc"),
        Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"),
    ]
    font_path = next((path for path in candidates if path.exists()), None)
    if font_path:
        font_manager.fontManager.addfont(font_path)
        plt.rcParams["font.family"] = font_manager.FontProperties(fname=font_path).get_name()
    else:
        raise RuntimeError("缺少中文字体。请安装微软雅黑/Noto CJK，或通过 CJK_FONT 指定字体文件。")
    plt.rcParams["axes.unicode_minus"] = False


def find_data(prefix: str) -> Path:
    matches = list(DATA_DIR.glob(f"{prefix}*.xlsx"))
    if len(matches) != 1:
        raise FileNotFoundError(f"应找到一个 {prefix}*.xlsx，实际找到 {len(matches)} 个")
    return matches[0]


def validate_hourly_time(values: pd.Series, label: str) -> None:
    times = pd.to_timedelta(values.astype(str), errors="coerce")
    expected = np.arange(24) * 3600
    if len(times) != 24 or times.isna().any() or times.nunique() != 24:
        raise ValueError(f"{label}时间列应包含 24 个不重复整点")
    if not np.array_equal(times.dt.total_seconds().to_numpy(), expected):
        raise ValueError(f"{label}时间列应按 00:00 至 23:00 每小时递增")


def load_typical_day() -> dict[str, pd.DataFrame]:
    load_raw = pd.read_excel(find_data("附件1"))
    gen_raw = pd.read_excel(find_data("附件2"), header=None).iloc[3:27, :5].copy()
    if len(load_raw) != 24 or len(gen_raw) != 24:
        raise ValueError("典型日数据应包含 24 个整点")

    validate_hourly_time(load_raw.iloc[:, 0], "附件1")
    validate_hourly_time(gen_raw.iloc[:, 0], "附件2")
    load = load_raw.iloc[:, 1:4].apply(pd.to_numeric)
    gen = gen_raw.iloc[:, 1:5].apply(pd.to_numeric)
    if not np.isfinite(load.to_numpy()).all() or not np.isfinite(gen.to_numpy()).all():
        raise ValueError("清洗后的典型日数据仍有缺失值")
    if (load < 0).any().any():
        raise ValueError("典型日负荷不能为负")
    if ((gen < 0) | (gen > 1)).any().any():
        raise ValueError("典型日风光标幺值应位于 0 至 1")
    for column, park in enumerate(PARKS):
        if not np.isclose(load.iloc[:, column].max(), PARKS[park]["max_load_kw"]):
            raise ValueError(f"园区 {park} 最大负荷与题设不一致")

    hours = np.arange(24)
    return {
        "A": pd.DataFrame({"hour": hours, "load": load.iloc[:, 0].to_numpy(), "pv": gen.iloc[:, 0].to_numpy() * 750, "wind": 0.0}),
        "B": pd.DataFrame({"hour": hours, "load": load.iloc[:, 1].to_numpy(), "pv": 0.0, "wind": gen.iloc[:, 1].to_numpy() * 1000}),
        "C": pd.DataFrame({"hour": hours, "load": load.iloc[:, 2].to_numpy(), "pv": gen.iloc[:, 2].to_numpy() * 600, "wind": gen.iloc[:, 3].to_numpy() * 500}),
    }


def load_monthly_generation(loads: dict[str, pd.DataFrame]) -> dict[int, dict[str, pd.DataFrame]]:
    raw = pd.read_excel(find_data("附件3"), header=None)
    values = raw.iloc[4:28, :49].copy()
    if len(values) != 24:
        raise ValueError("月度典型日数据应包含 24 个整点")

    validate_hourly_time(values.iloc[:, 0], "附件3")
    out: dict[int, dict[str, pd.DataFrame]] = {}
    for month in range(1, 13):
        start = 1 + (month - 1) * 4
        block = values.iloc[:, start : start + 4].apply(pd.to_numeric)
        if block.shape != (24, 4) or not np.isfinite(block.to_numpy()).all():
            raise ValueError(f"{month} 月风光数据存在缺失值")
        if ((block < 0) | (block > 1)).any().any():
            raise ValueError(f"{month} 月风光标幺值应位于 0 至 1")
        out[month] = {
            "A": pd.DataFrame({"hour": np.arange(24), "load": loads["A"]["load"], "pv": block.iloc[:, 0].to_numpy() * 750, "wind": 0.0}),
            "B": pd.DataFrame({"hour": np.arange(24), "load": loads["B"]["load"], "pv": 0.0, "wind": block.iloc[:, 1].to_numpy() * 1000}),
            "C": pd.DataFrame({"hour": np.arange(24), "load": loads["C"]["load"], "pv": block.iloc[:, 3].to_numpy() * 600, "wind": block.iloc[:, 2].to_numpy() * 500}),
        }
    return out


def renewable_accounting(df: pd.DataFrame, accepted: np.ndarray) -> tuple[float, float]:
    """按每小时风光出力比例分摊利用量和弃电量，不假定光伏优先。"""
    total = (df["pv"] + df["wind"]).to_numpy(float)
    ratio_pv = np.divide(df["pv"].to_numpy(float), total, out=np.zeros_like(total), where=total > 0)
    pv_used = float(np.sum(accepted * ratio_pv) * DT)
    wind_used = float(np.sum(accepted * (1 - ratio_pv)) * DT)
    return pv_used, wind_used


def renewable_unit_cost(df: pd.DataFrame) -> np.ndarray:
    """返回每个时刻风光混合出力的单位成本。"""
    pv = df["pv"].to_numpy(float)
    wind = df["wind"].to_numpy(float)
    total = pv + wind
    return np.divide(pv * PV_COST + wind * WIND_COST, total, out=np.zeros_like(total), where=total > 0)


def summarize(df: pd.DataFrame, grid: np.ndarray, curtailed: np.ndarray, charge: np.ndarray | None = None, prices: np.ndarray | None = None) -> dict[str, float | None]:
    renewable = (df["pv"] + df["wind"]).to_numpy(float)
    accepted = renewable - curtailed
    pv_used, wind_used = renewable_accounting(df, accepted)
    price = np.full(len(df), GRID_PRICE) if prices is None else prices
    grid_cost = float(np.sum(grid * price) * DT)
    renewable_cost = pv_used * PV_COST + wind_used * WIND_COST
    load_energy = float(df["load"].sum() * DT)
    total_cost = grid_cost + renewable_cost
    return {
        "load_kwh": load_energy,
        "renewable_generated_kwh": float(np.sum(renewable) * DT),
        "renewable_used_kwh": pv_used + wind_used,
        "grid_purchase_kwh": float(np.sum(grid) * DT),
        "curtailment_kwh": float(np.sum(curtailed) * DT),
        "charge_input_kwh": 0.0 if charge is None else float(np.sum(charge) * DT),
        "grid_cost_yuan": grid_cost,
        "renewable_cost_yuan": renewable_cost,
        "total_cost_yuan": total_cost,
        "unit_cost_yuan_per_kwh": total_cost / load_energy if load_energy > 0 else None,
    }


def baseline(df: pd.DataFrame, prices: np.ndarray | None = None) -> dict:
    load = df["load"].to_numpy(float)
    renewable = (df["pv"] + df["wind"]).to_numpy(float)
    grid = np.maximum(load - renewable, 0)
    curtailed = np.maximum(renewable - load, 0)
    return {"grid": grid, "curtailed": curtailed, "metrics": summarize(df, grid, curtailed, prices=prices)}


def greedy_storage(df: pd.DataFrame, power_kw: float, energy_kwh: float, prices: np.ndarray | None = None) -> dict:
    """重复代表日并衔接余电，返回满足日初=日末的规则策略稳态。"""
    if power_kw < 0 or energy_kwh < 0:
        raise ValueError("储能功率与容量不能为负")
    load = df["load"].to_numpy(float)
    renewable = (df["pv"] + df["wind"]).to_numpy(float)
    surplus = np.maximum(renewable - load, 0)
    deficit = np.maximum(load - renewable, 0)
    soc_min, soc_max = SOC_MIN_FRAC * energy_kwh, SOC_MAX_FRAC * energy_kwh
    soc = np.zeros(len(df) + 1)
    soc[0] = soc_min
    charge = np.zeros(len(df))
    discharge = np.zeros(len(df))

    for _ in range(100):
        for t in range(len(df)):
            charge[t] = max(0.0, min(surplus[t], power_kw, (soc_max - soc[t]) / (ETA_C * DT)))
            after_charge = soc[t] + charge[t] * ETA_C * DT
            discharge[t] = max(0.0, min(deficit[t], power_kw, (after_charge - soc_min) * ETA_D / DT))
            soc[t + 1] = after_charge - discharge[t] / ETA_D * DT
        if abs(soc[-1] - soc[0]) <= 1e-8:
            break
        soc[0] = soc[-1]
    else:
        raise RuntimeError("规则控制未收敛到代表日循环稳态")

    grid = deficit - discharge
    curtailed = surplus - charge
    metrics = summarize(df, grid, curtailed, charge, prices)
    result = {"grid": grid, "curtailed": curtailed, "charge": charge, "discharge": discharge, "soc": soc, "metrics": metrics}
    validate_dispatch(df, result, power_kw, energy_kwh)
    return result


def tou_prices() -> np.ndarray:
    price = np.ones(24)
    price[[0, 1, 2, 3, 4, 5, 6, 23]] = 0.6
    price[[8, 9, 10, 18, 19, 20, 21, 22]] = 1.2
    return price


def optimal_storage(df: pd.DataFrame, power_kw: float, energy_kwh: float, prices: np.ndarray, initial_energy: float | None = None) -> dict:
    """循环日调度；默认日初电量可优化，显式 initial_energy 仅用于边界敏感性。"""
    if power_kw < 0 or energy_kwh < 0:
        raise ValueError("储能功率与容量不能为负")
    if power_kw <= 0 or energy_kwh <= 0:
        result = {**baseline(df, prices), "charge": np.zeros(len(df)), "discharge": np.zeros(len(df)), "soc": np.full(len(df) + 1, SOC_MIN_FRAC * energy_kwh)}
        validate_dispatch(df, result, power_kw, energy_kwh)
        return result

    load = df["load"].to_numpy(float)
    renewable = (df["pv"] + df["wind"]).to_numpy(float)
    surplus = np.maximum(renewable - load, 0)
    deficit = np.maximum(load - renewable, 0)
    n = len(df)
    # 变量顺序：充电 c[0:n]，放电 d[0:n]，SOC e[0:n+1]
    # 基线中直接供给负荷的风光成本是常数；充电会增加风光利用成本，
    # 放电会减少购电成本，因此两者都应进入优化目标。
    charge_cost = renewable_unit_cost(df)
    objective = np.r_[charge_cost * DT + 1e-9, -prices * DT, np.zeros(n + 1)]
    a_eq = np.zeros((n + 1 + (initial_energy is not None), 3 * n + 1))
    b_eq = np.zeros(len(a_eq))
    for t in range(n):
        a_eq[t, t] = -ETA_C * DT
        a_eq[t, n + t] = DT / ETA_D
        a_eq[t, 2 * n + t] = -1
        a_eq[t, 2 * n + t + 1] = 1
    soc_min, soc_max = SOC_MIN_FRAC * energy_kwh, SOC_MAX_FRAC * energy_kwh
    a_eq[n, 2 * n] = 1
    a_eq[n, 3 * n] = -1
    if initial_energy is not None:
        if not soc_min <= initial_energy <= soc_max:
            raise ValueError("指定日初电量超出 SOC 边界")
        a_eq[n + 1, 2 * n] = 1
        b_eq[n + 1] = initial_energy
    bounds = (
        [(0, min(power_kw, float(s))) for s in surplus]
        + [(0, min(power_kw, float(d))) for d in deficit]
        + [(soc_min, soc_max)] * (n + 1)
    )
    solved = linprog(objective, A_eq=a_eq, b_eq=b_eq, bounds=bounds, method="highs")
    if not solved.success:
        raise RuntimeError(f"线性规划失败：{solved.message}")
    charge = solved.x[:n]
    discharge = solved.x[n : 2 * n]
    soc = solved.x[2 * n :]
    grid = deficit - discharge
    curtailed = surplus - charge
    result = {
        "grid": grid,
        "curtailed": curtailed,
        "charge": charge,
        "discharge": discharge,
        "soc": soc,
        "metrics": summarize(df, grid, curtailed, charge, prices),
    }
    validate_dispatch(df, result, power_kw, energy_kwh)
    return result


def validate_dispatch(df: pd.DataFrame, result: dict, power: float, energy: float) -> None:
    """每次求解均核验物理约束；失败时中止，不生成貌似成功的结果。"""
    c, d, e = (np.asarray(result[k]) for k in ("charge", "discharge", "soc"))
    grid, curt = result["grid"], result["curtailed"]
    net = (df["pv"] + df["wind"] - df["load"]).to_numpy(float)
    tol = 1e-6
    checks = [
        np.isfinite(np.r_[c, d, e, grid, curt]).all(),
        np.min(np.r_[c, d, grid, curt]) >= -tol,
        max(c.max(), d.max()) <= power + tol,
        e.min() >= SOC_MIN_FRAC * energy - tol,
        e.max() <= SOC_MAX_FRAC * energy + tol,
        np.max(c - np.maximum(net, 0)) <= tol,
        np.max(d - np.maximum(-net, 0)) <= tol,
        np.max(np.abs(net + grid + d - c - curt)) <= tol,
        np.max(np.abs(np.diff(e) - ETA_C*c*DT + d*DT/ETA_D)) <= tol,
        abs(e[-1] - e[0]) <= tol,
        np.max(np.minimum(c, d)) <= tol,
    ]
    if not all(checks):
        raise ValueError(f"调度约束检查失败，检查项：{checks}")


def annual_metrics(
    monthly: dict[int, dict[str, pd.DataFrame]],
    park: str,
    power_kw: float,
    energy_kwh: float,
    price_multiplier: float = 1.0,
    battery_cost_multiplier: float = 1.0,
    lifetime_years: float = BATTERY_LIFE_YEARS,
    fixed_start: bool = False,
) -> dict[str, float]:
    prices = tou_prices() * price_multiplier
    totals: dict[str, float] = {}
    for month in range(1, 13):
        days = monthrange(2026, month)[1]
        result = optimal_storage(monthly[month][park], power_kw, energy_kwh, prices,
                                 SOC_MIN_FRAC * energy_kwh if fixed_start else None)
        for key, value in result["metrics"].items():
            if key == "unit_cost_yuan_per_kwh":
                continue
            totals[key] = totals.get(key, 0.0) + value * days
    capex = (power_kw * BATTERY_POWER_COST + energy_kwh * BATTERY_ENERGY_COST) * battery_cost_multiplier
    totals["power_kw"] = power_kw
    totals["energy_kwh"] = energy_kwh
    totals["capex_yuan"] = capex
    totals["annualized_storage_cost_yuan"] = capex / lifetime_years
    totals["annual_total_cost_yuan"] = totals["total_cost_yuan"] + capex / lifetime_years
    totals["unit_cost_yuan_per_kwh"] = totals["total_cost_yuan"] / totals["load_kwh"]
    totals["annual_unit_cost_yuan_per_kwh"] = totals["annual_total_cost_yuan"] / totals["load_kwh"]
    return totals


def search_capacity(
    monthly: dict[int, dict[str, pd.DataFrame]],
    park: str,
    price_multiplier: float = 1.0,
    battery_cost_multiplier: float = 1.0,
    lifetime_years: float = BATTERY_LIFE_YEARS,
    fixed_start: bool = False,
) -> tuple[dict, list[dict]]:
    powers = [0, 25, 50, 75, 100, 150]
    energies = [0, 50, 100, 150, 200, 300]
    candidates = []
    for p in powers:
        for e in energies:
            if (p == 0) != (e == 0):
                continue
            candidates.append(annual_metrics(monthly, park, p, e, price_multiplier, battery_cost_multiplier, lifetime_years, fixed_start))
    best = min(candidates, key=lambda x: x["annual_total_cost_yuan"])
    return best, candidates


def pareto_analysis(candidates: list[dict]) -> dict:
    """筛选成本与弃电率的 Pareto 前沿，并给出三类推荐方案。"""
    rows = [
        {
            **row,
            "curtailment_rate_pct": 100 * row["curtailment_kwh"] / row["renewable_generated_kwh"],
        }
        for row in candidates
    ]
    pareto = []
    for row in rows:
        dominated = any(
            other["annual_total_cost_yuan"] <= row["annual_total_cost_yuan"] + 1e-8
            and other["curtailment_rate_pct"] <= row["curtailment_rate_pct"] + 1e-8
            and (
                other["annual_total_cost_yuan"] < row["annual_total_cost_yuan"] - 1e-8
                or other["curtailment_rate_pct"] < row["curtailment_rate_pct"] - 1e-8
            )
            for other in rows
        )
        if not dominated:
            pareto.append(row)
    pareto.sort(key=lambda row: row["annual_total_cost_yuan"])

    min_cost = min(row["annual_total_cost_yuan"] for row in pareto)
    max_cost = max(row["annual_total_cost_yuan"] for row in pareto)
    min_curt = min(row["curtailment_rate_pct"] for row in pareto)
    max_curt = max(row["curtailment_rate_pct"] for row in pareto)
    cost_span = max(max_cost - min_cost, 1e-9)
    curt_span = max(max_curt - min_curt, 1e-9)

    def ideal_distance(row: dict) -> float:
        return float(np.hypot(
            (row["annual_total_cost_yuan"] - min_cost) / cost_span,
            (row["curtailment_rate_pct"] - min_curt) / curt_span,
        ))

    return {
        "candidates": rows,
        "pareto": pareto,
        "economic": min(rows, key=lambda row: (row["annual_total_cost_yuan"], row["curtailment_rate_pct"])),
        "green": min(rows, key=lambda row: (row["curtailment_rate_pct"], row["annual_total_cost_yuan"])),
        "balanced": min(pareto, key=lambda row: (ideal_distance(row), row["annual_total_cost_yuan"])),
    }


def fixed_storage_economics(monthly: dict[int, dict[str, pd.DataFrame]], park: str) -> dict[str, float]:
    """用十二个月代表日复核题目给定 50 kW/100 kWh 方案的年化经济性。"""
    flat_prices = np.full(24, GRID_PRICE)
    baseline_cost = 0.0
    storage_cost = 0.0
    for month in range(1, 13):
        days = monthrange(2026, month)[1]
        df = monthly[month][park]
        baseline_cost += baseline(df, flat_prices)["metrics"]["total_cost_yuan"] * days
        storage_cost += greedy_storage(df, BATTERY_POWER, BATTERY_ENERGY, flat_prices)["metrics"]["total_cost_yuan"] * days
    capex = BATTERY_POWER * BATTERY_POWER_COST + BATTERY_ENERGY * BATTERY_ENERGY_COST
    annualized = capex / BATTERY_LIFE_YEARS
    operating_saving = baseline_cost - storage_cost
    return {
        "baseline_annual_operating_cost_yuan": baseline_cost,
        "storage_annual_operating_cost_yuan": storage_cost,
        "annual_operating_saving_yuan": operating_saving,
        "annualized_storage_cost_yuan": annualized,
        "storage_annual_total_cost_yuan": storage_cost + annualized,
        "net_annual_saving_yuan": operating_saving - annualized,
    }


def sensitivity_analysis(monthly: dict[int, dict[str, pd.DataFrame]], park: str) -> dict[str, list[dict[str, float]]]:
    """一次只改变一个参数，观察最优配置是否稳定。"""
    scenarios = {
        "grid_price": [(0.8, {"price_multiplier": 0.8}), (1.0, {}), (1.2, {"price_multiplier": 1.2})],
        "battery_cost": [(0.8, {"battery_cost_multiplier": 0.8}), (1.0, {}), (1.2, {"battery_cost_multiplier": 1.2})],
        "lifetime": [(8.0, {"lifetime_years": 8.0}), (10.0, {}), (12.0, {"lifetime_years": 12.0})],
    }
    out: dict[str, list[dict[str, float]]] = {}
    for factor, cases in scenarios.items():
        rows = []
        for level, kwargs in cases:
            best, _ = search_capacity(monthly, park, **kwargs)
            rows.append({"level": level, **best})
        out[factor] = rows
    return out


def plot_results(typical: dict[str, pd.DataFrame], daily: dict, tou: dict, capacity: dict, sensitivity: dict, multiobjective: dict) -> None:
    FIG_DIR.mkdir(exist_ok=True)
    colors = {"load": "#16324F", "renewable": "#2A9D8F", "grid": "#E76F51", "curtail": "#E9C46A", "storage": "#457B9D"}

    fig, axes = plt.subplots(3, 1, figsize=(10, 10), sharex=True)
    for ax, park in zip(axes, PARKS):
        df = typical[park]
        ax.plot(df["hour"], df["load"], label="负荷", color=colors["load"], linewidth=2)
        ax.plot(df["hour"], df["pv"] + df["wind"], label="风光出力", color=colors["renewable"], linewidth=2)
        ax.set_ylabel(f"园区 {park}\n功率/kW")
        ax.grid(alpha=0.25)
    axes[0].legend(ncol=2, loc="upper right")
    axes[-1].set_xlabel("时刻/h")
    fig.suptitle("三个园区典型日负荷与风光出力")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "01_typical_profiles.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    for ax, park in zip(axes, PARKS):
        df = typical[park]
        net_load = df["load"] - df["pv"] - df["wind"]
        ax.plot(df["hour"], net_load, color=colors["grid"], linewidth=2)
        ax.axhline(0, color="#5D6A73", linewidth=1)
        ax.fill_between(df["hour"], net_load, 0, where=net_load >= 0, color=colors["grid"], alpha=0.20, label="购电缺口")
        ax.fill_between(df["hour"], net_load, 0, where=net_load < 0, color=colors["renewable"], alpha=0.20, label="风光富余")
        ax.set_ylabel(f"园区 {park}\nkW")
        ax.grid(alpha=0.25)
    axes[0].legend(ncol=2, loc="upper right")
    axes[-1].set_xlabel("时刻/h")
    fig.suptitle("三个园区典型日净负荷")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "07_net_load.png", dpi=200)
    plt.close(fig)

    parks = list(PARKS)
    load_energy = [daily[p]["baseline"]["load_kwh"] for p in parks]
    ren_energy = [daily[p]["baseline"]["renewable_generated_kwh"] for p in parks]
    grid_energy = [daily[p]["baseline"]["grid_purchase_kwh"] for p in parks]
    curtail = [daily[p]["baseline"]["curtailment_kwh"] for p in parks]
    x = np.arange(3)
    fig, ax = plt.subplots(figsize=(10, 5.6))
    for i, (label, values, color) in enumerate([
        ("负荷电量", load_energy, colors["load"]), ("风光发电量", ren_energy, colors["renewable"]),
        ("电网购电量", grid_energy, colors["grid"]), ("弃风弃光量", curtail, colors["curtail"])]):
        ax.bar(x + (i - 1.5) * 0.19, values, width=0.18, label=label, color=color)
    ax.set_xticks(x, [f"园区 {p}" for p in parks])
    ax.set_ylabel("典型日电量/kWh")
    ax.set_title("无储能基线的电量平衡")
    ax.legend(ncol=2)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "02_baseline_balance.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.8))
    for ax, metric, title in [(axes[0], "grid_purchase_kwh", "电网购电量"), (axes[1], "curtailment_kwh", "弃风弃光量")]:
        base = [daily[p]["baseline"][metric] for p in parks]
        storage = [daily[p]["greedy"][metric] for p in parks]
        ax.bar(x - 0.18, base, 0.36, label="无储能", color="#A8B0B9")
        ax.bar(x + 0.18, storage, 0.36, label="50 kW/100 kWh", color=colors["storage"])
        ax.set_xticks(x, parks)
        ax.set_title(title)
        ax.set_ylabel("kWh/典型日")
        ax.grid(axis="y", alpha=0.25)
    axes[0].legend()
    fig.suptitle("储能前后对比")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "03_storage_comparison.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)
    for ax, park in zip(axes, parks):
        result = daily[park]["series"]
        soc_axis = ax.twinx()
        soc_axis.step(np.arange(25), 100*np.asarray(result["soc"])/BATTERY_ENERGY, where="post", color=colors["storage"], linewidth=2, label="SOC/%")
        soc_axis.set_ylim(0, 100)
        soc_axis.set_ylabel("SOC/%")
        ax.bar(np.arange(24), result["charge"], alpha=0.5, label="充电/kW", color=colors["renewable"])
        ax.bar(np.arange(24), -np.asarray(result["discharge"]), alpha=0.5, label="放电/kW", color=colors["grid"])
        ax.set_ylabel(f"园区 {park}\n充放电功率/kW")
        ax.grid(alpha=0.25)
        if park == "A":
            handles, labels = ax.get_legend_handles_labels()
            lines, names = soc_axis.get_legend_handles_labels()
            ax.legend(handles + lines, labels + names, ncol=3, loc="upper right")
    axes[-1].set_xlabel("时刻/h")
    fig.suptitle("50 kW/100 kWh 储能的规则控制过程")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "04_soc_dispatch.png", dpi=200)
    plt.close(fig)

    park = "C"
    fig, ax1 = plt.subplots(figsize=(10, 5.6))
    ax1.bar(np.arange(24) - 0.18, tou[park]["greedy"]["grid"], 0.36, label="规则控制购电", color="#A8B0B9")
    ax1.bar(np.arange(24) + 0.18, tou[park]["optimal"]["grid"], 0.36, label="优化控制购电", color=colors["storage"])
    ax1.set_xlabel("时刻/h")
    ax1.set_ylabel("购电功率/kW")
    ax2 = ax1.twinx()
    ax2.step(np.arange(25), np.r_[tou_prices(), tou_prices()[-1]], where="post", color=colors["grid"], linewidth=2, label="分时电价")
    ax2.set_ylabel("电价/(元/kWh)")
    lines, labels = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines + lines2, labels + labels2, ncol=3, loc="upper center")
    ax1.set_title("拓展一：园区 C 分时电价下的优化调度")
    ax1.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "05_tou_optimization.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.6))
    for ax, park, color in zip(axes, parks, ["#457B9D", "#2A9D8F", "#E76F51"]):
        rows = sorted(capacity[park]["candidates"], key=lambda r: (r["energy_kwh"], r["power_kw"]))
        best_by_energy = {}
        for row in rows:
            e = row["energy_kwh"]
            best_by_energy[e] = min(best_by_energy.get(e, row["annual_total_cost_yuan"]), row["annual_total_cost_yuan"])
        delta = (np.array(list(best_by_energy.values())) - best_by_energy[0]) / 10000
        ax.plot(list(best_by_energy), delta, marker="o", color=color)
        ax.axhline(0, color="#808080", linewidth=1, linestyle="--")
        best = capacity[park]["best"]
        ax.scatter(best["energy_kwh"], (best["annual_total_cost_yuan"]-best_by_energy[0])/10000, s=95, marker="*", color="#E76F51", zorder=3)
        ax.set_xlabel("储能容量/kWh")
        ax.set_title(f"园区 {park}：最优 {best['power_kw']:.0f}/{best['energy_kwh']:.0f}")
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("相对无储能的年成本变化/万元")
    fig.suptitle("各容量选最优功率；负值表示计入投资后仍节省成本")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "06_capacity_search.png", dpi=200)
    plt.close(fig)

    factor_info = [
        ("grid_price", "购电价格倍率", ["0.8", "1.0", "1.2"]),
        ("battery_cost", "储能成本倍率", ["0.8", "1.0", "1.2"]),
        ("lifetime", "储能寿命/年", ["8", "10", "12"]),
    ]
    fig, axes = plt.subplots(1, 3, figsize=(13, 4.6), sharey=True)
    for ax, (factor, title, labels) in zip(axes, factor_info):
        x_values = np.arange(3)
        for park, color in zip(parks, ["#457B9D", "#2A9D8F", "#E76F51"]):
            energy = [row["energy_kwh"] for row in sensitivity[park][factor]]
            ax.plot(x_values, energy, marker="o", linewidth=2, label=f"园区 {park}", color=color)
        ax.set_xticks(x_values, labels)
        ax.set_title(title)
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("最优储能容量/kWh")
    axes[0].legend()
    fig.suptitle("拓展六：关键参数变化下的最优容量")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "08_sensitivity.png", dpi=200)
    plt.close(fig)

    fig, axes = plt.subplots(1, 3, figsize=(13, 4.8), sharey=True)
    recommendation_styles = {
        "economic": ("经济优先", "#457B9D", "s"),
        "green": ("消纳优先", "#2A9D8F", "^"),
        "balanced": ("综合折中", "#E76F51", "*"),
    }
    for ax, park in zip(axes, parks):
        rows = capacity[park]["candidates"]
        front = multiobjective[park]["pareto"]
        ax.scatter(
            [row["annual_total_cost_yuan"] / 10000 for row in rows],
            [row["curtailment_rate_pct"] for row in rows],
            color="#B9C2CA", s=24, alpha=0.75, label="候选配置" if park == "A" else None,
        )
        ax.plot(
            [row["annual_total_cost_yuan"] / 10000 for row in front],
            [row["curtailment_rate_pct"] for row in front],
            color="#16324F", marker="o", linewidth=2, label="Pareto 前沿" if park == "A" else None,
        )
        seen = set()
        for key, (label, color, marker) in recommendation_styles.items():
            row = multiobjective[park][key]
            point = (row["power_kw"], row["energy_kwh"])
            ax.scatter(
                row["annual_total_cost_yuan"] / 10000,
                row["curtailment_rate_pct"],
                color=color, marker=marker, s=95, edgecolor="white", linewidth=0.8,
                label=label if park == "A" else None, zorder=5,
            )
            if point not in seen:
                ax.annotate(f"{point[0]:.0f}/{point[1]:.0f}", (row["annual_total_cost_yuan"] / 10000, row["curtailment_rate_pct"]), xytext=(4, 5), textcoords="offset points", fontsize=8)
                seen.add(point)
        ax.set_title(f"园区 {park}")
        ax.set_xlabel("年等效总成本/万元")
        ax.margins(x=0.18, y=0.12)
        ax.grid(alpha=0.25)
    axes[0].set_ylabel("弃风弃光率/%")
    axes[0].legend(fontsize=8)
    fig.suptitle("经济调度下候选配置的成本与弃电率 Pareto 前沿")
    fig.tight_layout()
    fig.savefig(FIG_DIR / "09_pareto_front.png", dpi=200)
    plt.close(fig)


def rounded_metrics(metrics: dict[str, float | None]) -> dict[str, float | None]:
    return {k: None if v is None else round(float(v), 4) for k, v in metrics.items()}


def write_results(daily: dict, tou: dict, capacity: dict, fixed_economics: dict, sensitivity: dict, multiobjective: dict) -> None:
    cost_increase = {
        park: 100 * (multiobjective[park]["balanced"]["annual_total_cost_yuan"] / multiobjective[park]["economic"]["annual_total_cost_yuan"] - 1)
        for park in PARKS
    }
    curtailment_drop = {
        park: multiobjective[park]["economic"]["curtailment_rate_pct"] - multiobjective[park]["balanced"]["curtailment_rate_pct"]
        for park in PARKS
    }
    lines = [
        "# 方向 B 计算结果",
        "",
        "## 1. 典型日基础任务",
        "",
        "| 园区 | 情景 | 购电量/kWh | 弃风弃光/kWh | 总成本/元 | 单位成本/(元/kWh) |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for park in PARKS:
        for label, key in [("无储能", "baseline"), ("规则储能", "greedy")]:
            m = daily[park][key]
            lines.append(f"| {park} | {label} | {m['grid_purchase_kwh']:.2f} | {m['curtailment_kwh']:.2f} | {m['total_cost_yuan']:.2f} | {m['unit_cost_yuan_per_kwh']:.4f} |")

    lines += [
        "",
        "说明：时间步长为 1 小时。规则策略重复代表日并衔接余电至循环稳态，日末电量等于日初。优化策略采用相同循环条件，日初电量在 10%–90% 容量内可优化。C 园区按每小时风光出力比例分摊利用量与成本。",
        "",
        "## 2. 50 kW/100 kWh 方案的年化经济性",
        "",
        "| 园区 | 无储能年运行成本/元 | 储能年运行成本/元 | 年运行节省/元 | 年化投资/元 | 净年节省/元 |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for park in PARKS:
        m = fixed_economics[park]
        lines.append(
            f"| {park} | {m['baseline_annual_operating_cost_yuan']:.2f} | {m['storage_annual_operating_cost_yuan']:.2f} | "
            f"{m['annual_operating_saving_yuan']:.2f} | {m['annualized_storage_cost_yuan']:.2f} | {m['net_annual_saving_yuan']:.2f} |"
        )

    lines += [
        "",
        "说明：附件 3 的每月代表日按循环稳态计算，再按 2026 年实际月天数加权。购电价格为固定 1 元/kWh。该表评价规则策略，不代表该容量在任意策略下均不经济。净年节省为负表示运行节省不足以覆盖年化投资。",
        "",
        "## 3. 拓展一与拓展五：线性规划和分时电价",
        "",
        "| 园区 | 规则控制成本/元 | 优化控制成本/元 | 节省/元 |",
        "|---|---:|---:|---:|",
    ]
    for park in PARKS:
        g = tou[park]["greedy"]["metrics"]["total_cost_yuan"]
        o = tou[park]["optimal"]["metrics"]["total_cost_yuan"]
        lines.append(f"| {park} | {g:.2f} | {o:.2f} | {g-o:.2f} |")

    lines += [
        "",
        "## 4. 拓展二：全年等效成本下的容量搜索",
        "",
        "| 园区 | 最优功率/kW | 最优容量/kWh | 年运行成本/元 | 年化储能成本/元 | 年等效总成本/元 |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for park in PARKS:
        b = capacity[park]["best"]
        lines.append(f"| {park} | {b['power_kw']:.0f} | {b['energy_kwh']:.0f} | {b['total_cost_yuan']:.2f} | {b['annualized_storage_cost_yuan']:.2f} | {b['annual_total_cost_yuan']:.2f} |")

    lines += [
        "",
        "## 5. 拓展六：敏感性分析",
        "",
        "| 园区 | 改变参数 | 参数值 | 最优功率/kW | 最优容量/kWh | 年等效总成本/元 |",
        "|---|---|---:|---:|---:|---:|",
    ]
    factor_names = {"grid_price": "购电价格倍率", "battery_cost": "储能成本倍率", "lifetime": "储能寿命/年"}
    for park in PARKS:
        for factor, rows in sensitivity[park].items():
            for row in rows:
                lines.append(
                    f"| {park} | {factor_names[factor]} | {row['level']:.1f} | {row['power_kw']:.0f} | "
                    f"{row['energy_kwh']:.0f} | {row['annual_total_cost_yuan']:.2f} |"
                )

    lines += [
        "",
        "## 6. 创新分析：成本—新能源消纳双目标配置",
        "",
        "仅在各配置采用经济最优调度得到的候选点中筛选：若不存在另一点在两个指标上均不劣、且至少一个严格更优，则该点为非支配点。综合折中方案采用等权归一化理想点距离；不是全部可行调度的连续双目标全局最优。",
        "",
        "| 园区 | 决策偏好 | 功率/kW | 容量/kWh | 年等效总成本/元 | 弃电率/% |",
        "|---|---|---:|---:|---:|---:|",
    ]
    labels = {"economic": "经济优先", "balanced": "综合折中", "green": "消纳优先"}
    for park in PARKS:
        for key, label in labels.items():
            row = multiobjective[park][key]
            lines.append(
                f"| {park} | {label} | {row['power_kw']:.0f} | {row['energy_kwh']:.0f} | "
                f"{row['annual_total_cost_yuan']:.2f} | {row['curtailment_rate_pct']:.2f} |"
            )

    lines += [
        "",
        "## 7. 最终结论（按条件区分）",
        "",
        "### 7.1 固定电价 + 固定 50 kW/100 kWh 储能",
        "",
        "- 储能能够减少三个园区的购电与弃电，说明技术上有效。",
        "- 在规则策略下计入每年 2.2 万元年化投资后，三个园区的净年节省均为负；此结论限定于该策略和当前参数。",
        "",
        "### 7.2 分时电价 + 优化调度 + 容量搜索",
        "",
        f"- 线性规划相对规则控制分别为 A、B、C 节省 {tou['A']['greedy']['metrics']['total_cost_yuan'] - tou['A']['optimal']['metrics']['total_cost_yuan']:.2f}、{tou['B']['greedy']['metrics']['total_cost_yuan'] - tou['B']['optimal']['metrics']['total_cost_yuan']:.2f}、{tou['C']['greedy']['metrics']['total_cost_yuan'] - tou['C']['optimal']['metrics']['total_cost_yuan']:.2f} 元/典型日。",
        f"- 只考虑年等效总成本时，A、B、C 的经济优先配置分别为 {capacity['A']['best']['power_kw']:.0f}/{capacity['A']['best']['energy_kwh']:.0f}、{capacity['B']['best']['power_kw']:.0f}/{capacity['B']['best']['energy_kwh']:.0f}、{capacity['C']['best']['power_kw']:.0f}/{capacity['C']['best']['energy_kwh']:.0f} kW/kWh。",
        "",
        "### 7.3 成本 + 弃电率双目标决策",
        "",
        f"- 综合折中配置分别为 A {multiobjective['A']['balanced']['power_kw']:.0f}/{multiobjective['A']['balanced']['energy_kwh']:.0f}、B {multiobjective['B']['balanced']['power_kw']:.0f}/{multiobjective['B']['balanced']['energy_kwh']:.0f}、C {multiobjective['C']['balanced']['power_kw']:.0f}/{multiobjective['C']['balanced']['energy_kwh']:.0f} kW/kWh。",
        f"- 相较经济优先方案，折中方案的年成本仅增加约 {cost_increase['A']:.2f}%、{cost_increase['B']:.2f}%、{cost_increase['C']:.2f}%，弃电率分别下降 {curtailment_drop['A']:.2f}、{curtailment_drop['B']:.2f}、{curtailment_drop['C']:.2f} 个百分点。",
        "",
        "以上三组结果并不矛盾，因为它们回答的是不同条件下的问题：固定方案是否值得投资、分时电价下怎样最省钱、以及愿意多承担少量成本时怎样减少弃电。",
        "",
        "局限：代表日内采用循环 SOC，但不同月份不衔接，不能刻画连续多日天气。月度负荷沿用同一曲线，未计衰减、维护与贴现；容量和 Pareto 结论仅适用于离散候选集。结果用于方法验证，不直接替代工程可研。",
    ]
    (ROOT / "results.md").write_text("\n".join(lines), encoding="utf-8")


def self_check() -> None:
    validate_hourly_time(pd.Series([f"{hour:02d}:00:00" for hour in range(24)]), "自检")
    try:
        validate_hourly_time(pd.Series(["00:00:00"] * 24), "自检")
    except ValueError:
        pass
    else:
        raise AssertionError("时间列校验未识别重复时点")
    df = pd.DataFrame({"hour": [0, 1], "load": [0.0, 10.0], "pv": [10.0, 0.0], "wind": [0.0, 0.0]})
    result = greedy_storage(df, 10, 20)
    assert result["charge"][0] > 0 and result["discharge"][1] > 0
    assert np.all(result["soc"] >= 2 - 1e-8) and np.all(result["soc"] <= 18 + 1e-8)
    prices = np.array([0.6, 1.2])
    opt = optimal_storage(df, 10, 20, prices)
    greedy = greedy_storage(df, 10, 20, prices)
    assert opt["metrics"]["grid_purchase_kwh"] < 10
    assert opt["metrics"]["total_cost_yuan"] <= greedy["metrics"]["total_cost_yuan"] + 1e-8
    assert abs(opt["soc"][0] - opt["soc"][-1]) < 1e-8
    demo = pareto_analysis([
        {"annual_total_cost_yuan": 10.0, "curtailment_kwh": 5.0, "renewable_generated_kwh": 10.0, "power_kw": 0.0, "energy_kwh": 0.0},
        {"annual_total_cost_yuan": 12.0, "curtailment_kwh": 3.0, "renewable_generated_kwh": 10.0, "power_kw": 1.0, "energy_kwh": 1.0},
        {"annual_total_cost_yuan": 13.0, "curtailment_kwh": 4.0, "renewable_generated_kwh": 10.0, "power_kw": 2.0, "energy_kwh": 2.0},
    ])
    assert len(demo["pareto"]) == 2
    assert demo["economic"]["power_kw"] == 0 and demo["green"]["power_kw"] == 1


def validate_dataset(typical: dict, monthly: dict) -> dict:
    """覆盖 3 个基础典型日与 36 个月度代表日，以及两种电价。"""
    cases = [(f"typical_{p}", df) for p, df in typical.items()]
    cases += [(f"month_{m}_{p}", df) for m, parks in monthly.items() for p, df in parks.items()]
    max_gap = 0.0
    for label, df in cases:
        for prices in (np.ones(24), tou_prices()):
            rule = greedy_storage(df, BATTERY_POWER, BATTERY_ENERGY, prices)
            opt = optimal_storage(df, BATTERY_POWER, BATTERY_ENERGY, prices)
            if opt["metrics"]["total_cost_yuan"] > rule["metrics"]["total_cost_yuan"] + 1e-6:
                raise AssertionError(f"{label} 优化成本高于可行规则策略")
            for result in (rule, opt):
                max_gap = max(max_gap, abs(float(result["soc"][-1]-result["soc"][0])))
                m = result["metrics"]
                loss = np.sum(result["charge"])*(1-ETA_C*ETA_D)*DT
                if abs(m["renewable_used_kwh"]+m["grid_purchase_kwh"]-m["load_kwh"]-loss)>1e-6:
                    raise AssertionError(f"{label} 周期能量守恒不满足")
    return {"representative_days": len(cases), "tariff_cases": 2*len(cases),
            "dispatch_checks": 4*len(cases), "max_cycle_gap_kwh": max_gap,
            "power_balance_soc_limits_and_cost_comparison": "passed"}


def main() -> None:
    configure_plot_font()
    self_check()
    typical = load_typical_day()
    monthly = load_monthly_generation(typical)
    prices = tou_prices()
    validation = validate_dataset(typical, monthly)

    daily = {}
    tou = {}
    for park, df in typical.items():
        base = baseline(df)
        greedy = greedy_storage(df, BATTERY_POWER, BATTERY_ENERGY)
        daily[park] = {
            "baseline": rounded_metrics(base["metrics"]),
            "greedy": rounded_metrics(greedy["metrics"]),
            "series": {k: v.tolist() for k, v in greedy.items() if isinstance(v, np.ndarray)},
        }
        tou_greedy = greedy_storage(df, BATTERY_POWER, BATTERY_ENERGY, prices)
        tou_optimal = optimal_storage(df, BATTERY_POWER, BATTERY_ENERGY, prices)
        tou[park] = {
            "greedy": {**tou_greedy, "metrics": rounded_metrics(tou_greedy["metrics"])},
            "optimal": {**tou_optimal, "metrics": rounded_metrics(tou_optimal["metrics"])},
        }

    capacity = {}
    fixed_economics = {}
    sensitivity = {}
    multiobjective = {}
    boundary_sensitivity = {}
    for park in PARKS:
        fixed_economics[park] = rounded_metrics(fixed_storage_economics(monthly, park))
        best, candidates = search_capacity(monthly, park)
        fixed_start_best, _ = search_capacity(monthly, park, fixed_start=True)
        boundary_sensitivity[park] = {"cyclic": rounded_metrics(best), "fixed_minimum": rounded_metrics(fixed_start_best)}
        pareto = pareto_analysis(candidates)
        capacity[park] = {"best": rounded_metrics(best), "candidates": [rounded_metrics(x) for x in pareto["candidates"]]}
        multiobjective[park] = {
            "pareto": [rounded_metrics(row) for row in pareto["pareto"]],
            "economic": rounded_metrics(pareto["economic"]),
            "green": rounded_metrics(pareto["green"]),
            "balanced": rounded_metrics(pareto["balanced"]),
        }
        raw_sensitivity = sensitivity_analysis(monthly, park)
        sensitivity[park] = {
            factor: [rounded_metrics(row) for row in rows]
            for factor, rows in raw_sensitivity.items()
        }

    plot_results(typical, daily, tou, capacity, sensitivity, multiobjective)
    write_results(daily, tou, capacity, fixed_economics, sensitivity, multiobjective)

    serializable_tou = {}
    for park, scenarios in tou.items():
        serializable_tou[park] = {}
        for name, result in scenarios.items():
            serializable_tou[park][name] = {
                **{k: v.tolist() for k, v in result.items() if isinstance(v, np.ndarray)},
                "metrics": result["metrics"],
            }
    payload = {
        "assumptions": {
            "dt_hours": DT,
            "grid_flat_price": GRID_PRICE,
            "pv_cost": PV_COST,
            "wind_cost": WIND_COST,
            "battery_power_kw": BATTERY_POWER,
            "battery_energy_kwh": BATTERY_ENERGY,
            "battery_power_cost_yuan_per_kw": BATTERY_POWER_COST,
            "battery_energy_cost_yuan_per_kwh": BATTERY_ENERGY_COST,
            "battery_life_years": BATTERY_LIFE_YEARS,
            "charge_efficiency": ETA_C,
            "discharge_efficiency": ETA_D,
            "soc_range": [SOC_MIN_FRAC, SOC_MAX_FRAC],
            "representative_day_boundary": "cyclic: E24=E0; optimized E0 is free within SOC bounds",
            "greedy_boundary": "repeat representative day with carried energy until cyclic steady state",
            "renewable_allocation": "hourly proportional PV/wind utilization and curtailment",
            "year": 2026,
            "monthly_load": "same attachment-1 typical load in each month; no inter-month linkage",
        },
        "typical": {p: {c: d[c].tolist() for c in d.columns} for p, d in typical.items()},
        "daily": daily,
        "tou": serializable_tou,
        "capacity": capacity,
        "fixed_economics": fixed_economics,
        "sensitivity": sensitivity,
        "multiobjective": multiobjective,
        "boundary_sensitivity": boundary_sensitivity,
        "validation": validation,
    }
    (ROOT / "analysis_results.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print("分析完成：results.md、analysis_results.json 和 9 张图已生成。")


if __name__ == "__main__":
    main()
