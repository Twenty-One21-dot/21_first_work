"""根据分析结果生成具有学术论文结构的中文 PDF。"""

from __future__ import annotations

import json
import os
from pathlib import Path

from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Image, KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle


ROOT = Path(__file__).resolve().parents[1]
RESULTS = json.loads((ROOT / "analysis_results.json").read_text(encoding="utf-8"))
OUT = ROOT / "report.pdf"


def register_fonts() -> tuple[str, str]:
    candidates = [
        (Path(os.environ.get("CJK_FONT", "__not_set__")), Path(os.environ.get("CJK_FONT", "__not_set__"))),
        (Path(r"C:\Windows\Fonts\msyh.ttc"), Path(r"C:\Windows\Fonts\msyhbd.ttc")),
        (Path("/System/Library/Fonts/PingFang.ttc"), Path("/System/Library/Fonts/PingFang.ttc")),
        (Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"), Path("/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc")),
    ]
    for regular, bold in candidates:
        if not regular.exists():
            continue
        try:
            pdfmetrics.registerFont(TTFont("ChineseRegular", str(regular)))
            pdfmetrics.registerFont(TTFont("ChineseBold", str(bold if bold.exists() else regular)))
            return "ChineseRegular", "ChineseBold"
        except Exception:
            continue
    raise RuntimeError("未找到可嵌入的中文 TrueType 字体。请用 CJK_FONT 指定兼容字体，避免生成缺字 PDF。")


FONT, FONT_BOLD = register_fonts()


def styles() -> dict[str, ParagraphStyle]:
    sheet = getSampleStyleSheet()
    return {
        "title": ParagraphStyle("title_cn", parent=sheet["Title"], fontName=FONT_BOLD, fontSize=18, leading=26, alignment=TA_CENTER, textColor=colors.black, spaceAfter=8),
        "english_title": ParagraphStyle("english_title_cn", parent=sheet["Title"], fontName=FONT_BOLD, fontSize=14, leading=19, alignment=TA_CENTER, textColor=colors.black, spaceBefore=5, spaceAfter=6),
        "subtitle": ParagraphStyle("subtitle_cn", parent=sheet["Normal"], fontName=FONT, fontSize=10, leading=16, alignment=TA_CENTER, textColor=colors.black),
        "author": ParagraphStyle("author_cn", parent=sheet["Normal"], fontName=FONT, fontSize=10.5, leading=17, alignment=TA_CENTER, textColor=colors.black),
        "h1": ParagraphStyle("h1_cn", parent=sheet["Heading1"], fontName=FONT_BOLD, fontSize=12, leading=19, textColor=colors.black, spaceBefore=10, spaceAfter=5, keepWithNext=True),
        "h2": ParagraphStyle("h2_cn", parent=sheet["Heading2"], fontName=FONT_BOLD, fontSize=10.5, leading=17, textColor=colors.black, spaceBefore=7, spaceAfter=4, keepWithNext=True),
        "body": ParagraphStyle("body_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=9.5, leading=16, alignment=TA_JUSTIFY, wordWrap="CJK", firstLineIndent=19, spaceAfter=3),
        "body_noindent": ParagraphStyle("body_noindent_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=9.5, leading=16, alignment=TA_JUSTIFY, wordWrap="CJK", spaceAfter=3),
        "abstract": ParagraphStyle("abstract_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=9, leading=15, alignment=TA_JUSTIFY, wordWrap="CJK", firstLineIndent=18, spaceAfter=4),
        "keywords": ParagraphStyle("keywords_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=9, leading=15, alignment=TA_LEFT, textColor=colors.black, spaceAfter=5),
        "small": ParagraphStyle("small_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=8, leading=12, textColor=colors.black),
        "small_header": ParagraphStyle("small_header_cn", parent=sheet["BodyText"], fontName=FONT_BOLD, fontSize=8, leading=12, textColor=colors.black),
        "caption": ParagraphStyle("caption_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=8.5, leading=13, alignment=TA_CENTER, textColor=colors.black, spaceAfter=5),
        "table_caption": ParagraphStyle("table_caption_cn", parent=sheet["BodyText"], fontName=FONT_BOLD, fontSize=8.5, leading=13, alignment=TA_CENTER, textColor=colors.black, spaceBefore=3, spaceAfter=3, keepWithNext=True),
        "formula": ParagraphStyle("formula_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=9.2, leading=16, alignment=TA_CENTER, spaceBefore=3, spaceAfter=4),
        "note": ParagraphStyle("note_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=8.5, leading=14, alignment=TA_JUSTIFY, wordWrap="CJK", textColor=colors.black, firstLineIndent=17, spaceBefore=2, spaceAfter=4),
        "reference": ParagraphStyle("reference_cn", parent=sheet["BodyText"], fontName=FONT, fontSize=8.5, leading=14, alignment=TA_JUSTIFY, wordWrap="CJK", leftIndent=12, firstLineIndent=-12, spaceAfter=3),
    }


S = styles()


def p(text: str, style: str = "body") -> Paragraph:
    return Paragraph(text, S[style])


def table(rows: list[list[object]], widths=None, align_numeric: bool = True) -> Table:
    converted = [
        [Paragraph(str(cell), S["small_header" if row_index == 0 else "small"]) for cell in row]
        for row_index, row in enumerate(rows)
    ]
    result = Table(converted, colWidths=widths, repeatRows=1, hAlign="CENTER")
    commands = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#E6E6E6")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.black),
        ("FONTNAME", (0, 0), (-1, 0), FONT_BOLD),
        ("ALIGN", (0, 0), (-1, 0), "CENTER"),
        ("ALIGN", (0, 1), (0, -1), "CENTER"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#A6A6A6")),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#F7F7F7")]),
        ("LEFTPADDING", (0, 0), (-1, -1), 5),
        ("RIGHTPADDING", (0, 0), (-1, -1), 5),
        ("TOPPADDING", (0, 0), (-1, -1), 5),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 5),
    ]
    if align_numeric:
        commands.append(("ALIGN", (1, 1), (-1, -1), "RIGHT"))
    result.setStyle(TableStyle(commands))
    return result


def table_block(title: str, rows: list[list[object]], widths=None, align_numeric: bool = True):
    return KeepTogether([p(title, "table_caption"), table(rows, widths, align_numeric)])


def figure(filename: str, caption: str, width=165 * mm):
    path = ROOT / "figures" / filename
    with PILImage.open(path) as source:
        px_width, px_height = source.size
    draw_width = width
    draw_height = width * px_height / px_width
    if draw_height > 102 * mm:
        draw_width *= (102 * mm) / draw_height
        draw_height = 102 * mm
    return [Spacer(1, 2.5 * mm), KeepTogether([Image(str(path), width=draw_width, height=draw_height), p(caption, "caption")])]


def fmt(value: float, digits: int = 2) -> str:
    return f"{value:,.{digits}f}"


def daily_table() -> list[list[object]]:
    rows = [["园区", "情景", "购电量/kWh", "弃电量/kWh", "运行成本/元", "单位成本/(元/kWh)"]]
    for park in "ABC":
        for label, key in [("无储能", "baseline"), ("规则储能", "greedy")]:
            metric = RESULTS["daily"][park][key]
            rows.append([park, label, fmt(metric["grid_purchase_kwh"]), fmt(metric["curtailment_kwh"]), fmt(metric["total_cost_yuan"]), fmt(metric["unit_cost_yuan_per_kwh"], 4)])
    return rows


def tou_table() -> list[list[object]]:
    rows = [["园区", "规则控制成本/元", "优化控制成本/元", "节省/元", "降幅/%"]]
    for park in "ABC":
        greedy = RESULTS["tou"][park]["greedy"]["metrics"]["total_cost_yuan"]
        optimal = RESULTS["tou"][park]["optimal"]["metrics"]["total_cost_yuan"]
        rows.append([park, fmt(greedy), fmt(optimal), fmt(greedy - optimal), fmt((greedy - optimal) / greedy * 100, 3)])
    return rows


def capacity_table() -> list[list[object]]:
    rows = [["园区", "功率/kW", "容量/kWh", "年运行成本/元", "年化投资/元", "年等效总成本/元"]]
    for park in "ABC":
        best = RESULTS["capacity"][park]["best"]
        rows.append([park, fmt(best["power_kw"], 0), fmt(best["energy_kwh"], 0), fmt(best["total_cost_yuan"]), fmt(best["annualized_storage_cost_yuan"]), fmt(best["annual_total_cost_yuan"])])
    return rows


def fixed_economic_table() -> list[list[object]]:
    rows = [["园区", "无储能年运行/元", "储能年运行/元", "年运行节省/元", "年化投资/元", "净年节省/元"]]
    for park in "ABC":
        metric = RESULTS["fixed_economics"][park]
        rows.append([
            park,
            fmt(metric["baseline_annual_operating_cost_yuan"]),
            fmt(metric["storage_annual_operating_cost_yuan"]),
            fmt(metric["annual_operating_saving_yuan"]),
            fmt(metric["annualized_storage_cost_yuan"]),
            fmt(metric["net_annual_saving_yuan"]),
        ])
    return rows


def sensitivity_table() -> list[list[object]]:
    rows = [["园区", "基准", "购电价+20%", "储能成本-20%", "寿命12年"]]
    for park in "ABC":
        data = RESULTS["sensitivity"][park]
        selected = [data["grid_price"][1], data["grid_price"][2], data["battery_cost"][0], data["lifetime"][2]]
        rows.append([park] + [f"{item['power_kw']:.0f}/{item['energy_kwh']:.0f}" for item in selected])
    return rows


def multiobjective_table() -> list[list[object]]:
    rows = [["园区", "决策偏好", "功率/kW", "容量/kWh", "年等效总成本/万元", "弃电率/%"]]
    labels = {"economic": "经济优先", "balanced": "综合折中", "green": "消纳优先"}
    for park in "ABC":
        for key, label in labels.items():
            item = RESULTS["multiobjective"][park][key]
            rows.append([
                park, label, fmt(item["power_kw"], 0), fmt(item["energy_kwh"], 0),
                fmt(item["annual_total_cost_yuan"] / 10000, 2), fmt(item["curtailment_rate_pct"], 2),
            ])
    return rows


def footer(canvas, doc) -> None:
    canvas.saveState()
    canvas.setFont(FONT, 8)
    canvas.setFillColor(colors.black)
    canvas.drawCentredString(105 * mm, 11 * mm, f"{doc.page}")
    canvas.restoreState()


def build() -> None:
    doc = SimpleDocTemplate(
        str(OUT), pagesize=A4, rightMargin=24 * mm, leftMargin=24 * mm,
        topMargin=20 * mm, bottomMargin=20 * mm,
        title="园区微电网风光储协调优化配置研究", author="罗大顺",
        subject="园区微电网储能优化配置、敏感性分析与多目标决策",
    )
    best = {park: RESULTS["capacity"][park]["best"] for park in "ABC"}
    multi = RESULTS["multiobjective"]
    fixed = RESULTS["fixed_economics"]
    closest = max(fixed, key=lambda park: fixed[park]["net_annual_saving_yuan"])
    boundary = RESULTS["boundary_sensitivity"]
    daily_saving = {
        park: RESULTS["daily"][park]["baseline"]["total_cost_yuan"] - RESULTS["daily"][park]["greedy"]["total_cost_yuan"]
        for park in "ABC"
    }
    tou_saving = {
        park: RESULTS["tou"][park]["greedy"]["metrics"]["total_cost_yuan"] - RESULTS["tou"][park]["optimal"]["metrics"]["total_cost_yuan"]
        for park in "ABC"
    }
    cost_increase = {
        park: 100 * (multi[park]["balanced"]["annual_total_cost_yuan"] / multi[park]["economic"]["annual_total_cost_yuan"] - 1)
        for park in "ABC"
    }
    curtailment_drop = {
        park: multi[park]["economic"]["curtailment_rate_pct"] - multi[park]["balanced"]["curtailment_rate_pct"]
        for park in "ABC"
    }

    story = [
        p("园区微电网风光储协调优化配置研究", "title"),
        p("罗大顺", "author"),
        p("（西华大学电气 Club 论文组）", "subtitle"),
        Spacer(1, 3 * mm),
        p("摘　要", "h1"),
        p(
            f"目的：分析园区微电网中风光出力与负荷时序错位造成的购电和弃电，并在经济性与新能源消纳之间提出可解释的储能配置建议。方法：针对 A、B、C 三个园区构建小时级能量平衡模型，依次开展无储能基线、50 kW/100 kWh 规则储能、分时电价线性规划、十二个月代表日容量搜索、敏感性分析以及成本-弃电率 Pareto 决策。结果：在固定 1 元/kWh 购电价格下，固定储能均能减少购电与弃电，但计入年化投资后，A、B、C 的净年节省分别为 {fixed['A']['net_annual_saving_yuan']:,.2f}、{fixed['B']['net_annual_saving_yuan']:,.2f} 和 {fixed['C']['net_annual_saving_yuan']:,.2f} 元；分时电价下，优化调度相对规则控制分别节省 {tou_saving['A']:.2f}、{tou_saving['B']:.2f} 和 {tou_saving['C']:.2f} 元/典型日；在分时电价与基准经济参数下，三个园区的经济优先配置依次为 {best['A']['power_kw']:.0f}/{best['A']['energy_kwh']:.0f}、{best['B']['power_kw']:.0f}/{best['B']['energy_kwh']:.0f} 和 {best['C']['power_kw']:.0f}/{best['C']['energy_kwh']:.0f} kW/kWh，Pareto 综合折中配置依次为 {multi['A']['balanced']['power_kw']:.0f}/{multi['A']['balanced']['energy_kwh']:.0f}、{multi['B']['balanced']['power_kw']:.0f}/{multi['B']['balanced']['energy_kwh']:.0f} 和 {multi['C']['balanced']['power_kw']:.0f}/{multi['C']['balanced']['energy_kwh']:.0f} kW/kWh。结论：储能在技术上有效并不等同于经济可行，合理配置同时取决于价格、设备成本、寿命以及园区对新能源消纳的偏好。",
            "abstract",
        ),
        p("关键词：园区微电网；风光储；线性规划；储能容量配置；Pareto 前沿；敏感性分析", "keywords"),
        p("Coordinated Optimal Configuration of Wind-Photovoltaic-Storage Systems in Industrial Park Microgrids", "english_title"),
        p("LUO Dashun", "author"),
        p("(Electrical Club Paper Group, Xihua University)", "subtitle"),
        p("Abstract", "h1"),
        p(
            f"Objective: This study investigates grid purchases and renewable curtailment caused by temporal mismatch between renewable generation and electrical load in three industrial parks. Methods: An hourly energy-balance model compares a no-storage baseline, a rule-based 50 kW/100 kWh battery, and optimized dispatch. Linear programming, twelve monthly representative days, discrete sizing, sensitivity analysis, and a cost-curtailment Pareto extension are combined in one workflow. Results: At a fixed grid tariff of 1 yuan/kWh, the fixed battery improves technical indicators, but its operating savings do not recover annualized investment. Under the time-of-use tariff and baseline economic parameters, the economic configurations are {best['A']['power_kw']:.0f}/{best['A']['energy_kwh']:.0f}, {best['B']['power_kw']:.0f}/{best['B']['energy_kwh']:.0f}, and {best['C']['power_kw']:.0f}/{best['C']['energy_kwh']:.0f} kW/kWh for Parks A, B, and C, while the balanced Pareto configurations are {multi['A']['balanced']['power_kw']:.0f}/{multi['A']['balanced']['energy_kwh']:.0f}, {multi['B']['balanced']['power_kw']:.0f}/{multi['B']['balanced']['energy_kwh']:.0f}, and {multi['C']['balanced']['power_kw']:.0f}/{multi['C']['balanced']['energy_kwh']:.0f} kW/kWh. Conclusion: Technical effectiveness does not guarantee economic feasibility; storage sizing depends jointly on economic assumptions and renewable-consumption preferences.",
            "abstract",
        ),
        p("Key words: industrial park microgrid; wind-photovoltaic-storage system; linear programming; battery sizing; Pareto frontier; sensitivity analysis", "keywords"),
        p("1　引言", "h1"),
        p("1.1　研究背景与问题提出", "h2"),
        p("园区微电网通过就地配置风电、光伏和储能，可降低对外部电网的依赖并提高可再生能源消纳率。然而，风光出力具有波动性，园区负荷也随时间变化，两者不匹配时会同时出现缺电购电和富余弃电。储能能够在时间上转移电量，但其功率、容量和寿命成本又可能抵消运行收益。因此，仅证明储能能够减少购电并不足以说明方案经济可行，还需要在统一成本口径下比较运行节省与投资。"),
        p("围绕上述矛盾，本文回答四个研究问题：RQ1，题设固定储能在技术指标和全年经济性上分别产生什么影响；RQ2，分时电价下线性规划相较简单规则能否进一步降低运行成本；RQ3，在价格、投资和寿命不确定时，最优储能配置是否稳定；RQ4，同时考虑经济成本与新能源消纳时，如何向园区提供不同决策偏好的配置方案。"),
        p("1.2　相关研究", "h2"),
        p("Chen、Gooi 与 Wang 研究的问题是：微电网中储能容量如何与运行策略协调选择，才能在投资成本与运行收益之间取得最优平衡。作者建立了包含储能功率、能量状态和微电网运行约束的优化模型，说明容量选择不能脱离调度策略[2]。Yang 等进一步综述了可再生能源系统中的储能定容方法，重点比较不同技术指标、经济指标、时间尺度和输入数据对定容结论的影响，其研究问题是如何系统选择适用于不同场景的储能规模确定方法[3]。本文不复现复杂的随机规划或全年逐时模型，而是针对题目给出的代表日数据，采用可解释、可复核的确定性线性规划和离散候选搜索，完成从基线计算到经济性分析的完整流程。"),
        p("1.3　本文工作与结构", "h2"),
        p("本文建立统一的小时级能量与成本核算方法，在规则控制基础上构建线性规划模型，并显式计入因充电增加的风光利用成本。随后利用月度代表日开展功率—容量组合搜索和敏感性分析。进一步地，本文将年等效总成本与弃电率作为双目标，利用 Pareto 非支配关系筛选有效方案，并用归一化理想点距离推荐综合折中配置。第 2 节介绍数据与假设，第 3 节给出模型，第 4 节说明实验设计，第 5 节报告结果，第 6 节讨论工程含义与局限，第 7 节总结全文。"),
        p("1.4　研究逻辑与问题映射", "h2"),
        table_block("表 1　研究问题、分析方法与结论输出的对应关系", [["研究问题", "需要回答的核心问题", "分析方法", "对应输出"], ["RQ1", "固定储能是否技术有效且经济可行", "基线、规则控制、全年年化", "技术效果与净年节省"], ["RQ2", "主动调度能否降低运行成本", "分时电价线性规划", "规则与优化成本差"], ["RQ3", "经济配置是否随参数改变", "容量搜索与敏感性分析", "最优配置及稳健性"], ["RQ4", "如何兼顾成本与新能源消纳", "Pareto 筛选与理想点", "经济、折中、消纳方案"]], [17 * mm, 57 * mm, 47 * mm, 44 * mm], align_numeric=False),
        p("全文遵循“先判断有没有用，再判断是否值得投资，随后寻找经济配置，最后讨论多目标取舍”的递进逻辑。第 3 节将四个问题转化为模型，第 4 节设置对应实验，第 5 节按 RQ1 至 RQ4 的顺序给出证据。", "note"),
        p("2　数据来源、预处理与基本假设", "h1"),
        p("2.1　数据来源与预处理", "h2"),
        p("原始数据来自题目指定的公开数据仓库[1]。附件 1 含三个园区 24 个整点的负荷功率，附件 2 含典型日风光标幺出力，附件 3 含十二个月代表日风光标幺出力。程序使用 Pandas 读取 Excel，截取有效数值区，转换为浮点数并检查行数与缺失值。标幺出力乘对应装机容量后得到实际功率，时间步长 Δt 取 1 h。"),
        table_block("表 2　园区电源与负荷参数", [["园区", "风电装机/kW", "光伏装机/kW", "最大负荷/kW"], ["A", "0", "750", "447"], ["B", "1000", "0", "419"], ["C", "500", "600", "506"]], [25 * mm, 38 * mm, 38 * mm, 38 * mm]),
        p("2.2　成本与储能参数", "h2"),
        p("基础电价为 1 元/kWh，风电和光伏使用成本分别为 0.5 元/kWh 和 0.4 元/kWh。题设固定储能额定功率 50 kW、额定容量 100 kWh，充放电效率均为 95%，SOC 允许范围为 10% 至 90%。扩展经济性分析采用功率成本 800 元/kW、容量成本 1800 元/kWh 和 10 年寿命。"),
        p("2.3　研究假设", "h2"),
        p("为使模型与题目数据保持一致，作如下假设：储能仅吸收园区富余风光，不从电网充电；园区不允许向主网反送电；同一小时内不人为安排同时充放电；容量搜索中各月负荷沿用附件 1 典型日，各月风光采用附件 3 代表日；暂不考虑衰减、维护费、税费、贴现率、需量电费和停电损失。上述假设决定了本文结论的适用范围。", "body_noindent"),
        p("C 园区同一小时的风电和光伏利用量、弃电量均按原始出力比例分摊，故混合绿电单价为 cr,t = (0.4Ppv,t + 0.5Pwind,t)/(Ppv,t + Pwind,t)，零出力时取 0。该口径不是光伏优先策略；由于两类电源价格不同，成本结论须与此分摊假设一起使用。"),
        p("完成数据与边界条件定义后，下一步需要把购电、弃电、储能运行和投资成本转化为可计算的目标函数与约束。", "note"),
    ]

    story += figure("01_typical_profiles.png", "图 1　三个园区典型日负荷与风光出力")
    story += figure("07_net_load.png", "图 2　三个园区典型日净负荷；正值表示功率缺额，负值表示风光富余")
    story += [
        p("3　数学模型与求解方法", "h1"),
        p("本节按研究问题的递进关系建立四层模型：基线与规则模型回答 RQ1，线性规划回答 RQ2，容量搜索与敏感性分析回答 RQ3，双目标决策回答 RQ4。四层模型共享同一能量平衡和成本口径，保证各情景能够直接比较。", "body_noindent"),
        p("3.1　符号定义", "h2"),
        table_block("表 3　主要符号及含义", [["符号", "含义", "单位"], ["Pload,t", "t 时刻负荷功率", "kW"], ["Pr,t", "t 时刻风光总出力", "kW"], ["Pgrid,t", "t 时刻电网购电功率", "kW"], ["Pch,t / Pdis,t", "t 时刻充电/放电功率", "kW"], ["Pcurt,t", "t 时刻弃风弃光功率", "kW"], ["Et", "t 时刻储能电量", "kWh"], ["ηc / ηd", "充电/放电效率", "—"]], [34 * mm, 92 * mm, 25 * mm], align_numeric=False),
        p("3.2　无储能基线", "h2"),
        p("净负荷定义为负荷减风光总出力。净负荷为正时由主电网补足，为负时形成弃电。因此，无储能基线可写为："),
        p("Pgrid,t = max(Pload,t - Pr,t, 0)　；　Pcurt,t = max(Pr,t - Pload,t, 0)　　(1)", "formula"),
        p("日购电量与弃电量分别为上述功率在 24 h 内的离散积分。该基线既是固定储能节省量的参照，也是后续线性规划目标中的常数成本来源。"),
        p("3.3　规则储能模型", "h2"),
        p("规则控制优先使用风光直接供给负荷；存在富余时在功率和 SOC 允许范围内充电，存在缺额时放电。储能状态转移为："),
        p("Et+1 = Et + ηc Pch,t Δt - Pdis,t Δt / ηd　　(2)", "formula"),
        p("0 ≤ Pch,t ≤ min(max(Pr,t - Pload,t, 0), Pn)　　(3a)", "formula"),
        p("0 ≤ Pdis,t ≤ min(max(Pload,t - Pr,t, 0), Pn)　　(3b)", "formula"),
        p("0.1En ≤ Et ≤ 0.9En　　(4)", "formula"),
        p("式中 Pn 和 En 分别为储能额定功率与额定容量，SOCt = Et/En。规则控制每小时在上述边界内尽量充电或放电。先从 10% 电量启动，再把日末电量传给下一次相同代表日，直到 E24 = E0；只统计循环稳态的单日结果，不把预热过程计入代表日。这样避免每天清空余电或消耗免费初始电量。规则控制不预留电量等待更高电价。"),
        p("3.4　线性规划优化调度", "h2"),
        p("在线性规划中，决策变量为各时刻充电功率、放电功率和储能电量。由于基线直接供负荷的风光成本为常数，优化只需权衡充电增加的风光利用成本与放电减少的购电成本；等价目标写为："),
        p("min Σt [cg,t Pgrid,t + cr,t Pch,t] Δt　　(5)", "formula"),
        p("其中 cg,t 为分时购电价格，cr,t 为按出力加权的绿电单价。另有 Pgrid,t = max(Pload,t - Pr,t, 0) - Pdis,t，Pcurt,t = max(Pr,t - Pload,t, 0) - Pch,t。式（2）至（4）与 E24 = E0 共同构成约束，E0 在 0.1En 至 0.9En 内自由优化，不固定在下限。循环条件保证日内无净透支，并允许午夜前后移峰。使用 SciPy 的 linprog 和 HiGHS 求解。"),
        p("3.5　成本核算与容量配置", "h2"),
        p("运行成本包括购电与实际利用的风光成本。投资按寿命直线摊销，年等效总成本为："),
        p("Cannual = Coperation + (800Pn + 1800En) / L　　(6)", "formula"),
        p("其中 L 为寿命年数。功率候选集合为 {0, 25, 50, 75, 100, 150} kW，容量候选集合为 {0, 50, 100, 150, 200, 300} kWh；对所有有效组合逐一计算年等效总成本并选择最小值。该方法保证候选集合内最优，但不代表连续变量意义下的全局最优。"),
        p("3.6　敏感性分析", "h2"),
        p("采用单因素法检验结论稳定性：购电价格倍率和储能成本倍率均取 0.8、1.0、1.2，寿命取 8、10、12 年；每次只改变一个参数，其余保持基准值，并重新执行完整容量搜索。"),
        p("3.7　成本—新能源消纳双目标决策", "h2"),
        p("本文对每个候选配置先求经济最优调度，再计算其年等效总成本与弃电率，并在这些离散候选点中筛选非支配方案。该步骤是配置层面的多指标决策，不代表对所有可行调度求得完整双目标前沿。弃电率按下式计算。"),
        p("Rcurt = Ecurt / Erenew × 100%　　(7)", "formula"),
        p("若不存在另一候选点在两个指标上均不劣且至少一个严格更优，则该点为非支配点。分别给出其中成本最低、弃电率最低的方案，并对非支配点采用 min-max 归一化，以等权理想点距离最小者作为折中方案。等权是一种决策偏好，而非客观唯一答案："),
        p("di = √[(Ci - Cmin)²/(Cmax - Cmin)² + (Ri - Rmin)²/(Rmax - Rmin)²]　　(8)", "formula"),
        p("4　实验设计与模型验证", "h1"),
        p("为避免方法与结果脱节，实验情景 S0 至 S5 依次对应基线、固定储能、优化调度、经济配置、稳健性检验和双目标决策。除被考察因素外，其余参数保持一致。", "body_noindent"),
        p("4.1　实验情景", "h2"),
        table_block("表 4　研究情景设置", [["情景", "储能/电价", "控制方法", "用途"], ["S0", "无储能/固定电价", "基线计算", "获得参照"], ["S1", "50 kW/100 kWh/固定电价", "规则控制", "评价题设方案"], ["S2", "50 kW/100 kWh/分时电价", "规则与线性规划", "比较调度策略"], ["S3", "多组功率与容量/分时电价", "线性规划+离散搜索", "获得经济配置"], ["S4", "参数扰动", "单因素敏感性", "检验稳定性"], ["S5", "全部候选配置", "Pareto 筛选+理想点", "成本与消纳决策"]], [18 * mm, 47 * mm, 48 * mm, 42 * mm], align_numeric=False),
        p("4.2　全年等效方法", "h2"),
        p("对附件 3 的每个月代表日分别按循环条件求解，再乘以 2026 年该月实际天数。规则策略与优化策略均满足日初、日末电量相等。不同月份的循环初值不相互衔接，不能描述真实连续天气或跨月储能，因此称为“全年等效”，而非 8760 小时连续仿真。"),
        p("4.3　程序实现与自检", "h2"),
        p("数据处理采用 Pandas 与 NumPy，求解采用 SciPy，绘图采用 Matplotlib。程序检查 24 个连续整点、有限数值、非负负荷和标幺范围。每次调度均验证功率平衡、SOC 递推、充放电限值及初末一致。对 3 个基础典型日和 36 个月度代表日，分别在固定与分时电价下校验规则和优化策略，共 156 组调度，并检查优化成本不高于同容量可行规则策略。"),
        p("独立测试另用累计充放电量消去状态变量，复算 78 组固定容量情景和全部 26×3×12 组基准配置调度，并覆盖零储能、零负荷、无风光、持续富余及循环起点平移。结果表由 JSON 读取，图由同批计算生成。测试命令为 python code/test_analysis.py。", "note"),
        p("模型验证说明：能量守恒可由每小时功率平衡和 SOC 递推同时检查；固定储能情景中，因充放电效率小于 1，弃电减少量应大于购电减少量，该特征在计算结果中得到满足。", "note"),
        PageBreak(),
        p("5　结果与分析", "h1"),
        p("结果按“基线参照-RQ1 固定储能-RQ2 优化调度-RQ3 配置稳健性-RQ4 双目标决策”的顺序展开。每一组结果均先给出数据证据，再明确回答对应研究问题。", "body_noindent"),
        p("5.1　无储能基线", "h2"),
    ]

    story += figure("02_baseline_balance.png", "图 3　无储能基线的典型日电量平衡")
    story += [
        p("A 园区仅配置光伏，白天存在明显富余而夜间持续购电；B 园区风电装机较大，全天均可能出现出力波动；C 园区同时配置风电与光伏，资源互补降低了部分缺额，但仍存在购电和弃电。购电与弃电同时较高并不矛盾，因为二者发生在不同小时。"),
        p("5.2　固定储能的技术效果", "h2"),
        table_block("表 5　固定储能前后的典型日运行指标", daily_table(), [15 * mm, 23 * mm, 28 * mm, 28 * mm, 27 * mm, 40 * mm]),
    ]
    story += figure("03_storage_comparison.png", "图 4　无储能与 50 kW/100 kWh 储能运行指标对比")
    story += figure("04_soc_dispatch.png", "图 5　三个园区规则控制下的充放电功率与 SOC")
    story += [
        p(f"固定储能在三个园区均减少购电和弃电。B 园区改善最明显：典型日购电量由 {RESULTS['daily']['B']['baseline']['grid_purchase_kwh']:.2f} kWh 降至 {RESULTS['daily']['B']['greedy']['grid_purchase_kwh']:.2f} kWh，弃电量由 {RESULTS['daily']['B']['baseline']['curtailment_kwh']:.2f} kWh 降至 {RESULTS['daily']['B']['greedy']['curtailment_kwh']:.2f} kWh。A、B、C 的典型日运行成本分别降低 {daily_saving['A']:.2f}、{daily_saving['B']:.2f} 和 {daily_saving['C']:.2f} 元。由于充放电存在效率损失，减少的弃电量大于减少的购电量，结果符合物理预期。"),
        PageBreak(),
        p("5.3　固定方案的全年经济性", "h2"),
        table_block("表 6　50 kW/100 kWh 固定储能的全年经济性", fixed_economic_table(), [13 * mm, 29 * mm, 29 * mm, 27 * mm, 25 * mm, 26 * mm]),
        p(f"固定方案投资为 22 万元，按 10 年直线年化后为 2.2 万元/年。在循环规则策略下，三个园区的运行节省不足以覆盖年化投资；其中 {closest} 园区净年节省为 {fixed[closest]['net_annual_saving_yuan']:,.2f} 元，最接近盈亏平衡。RQ1 的答案限定于规则策略和当前参数，不能据此断言该容量在任意优化策略下都不经济。"),
        p("5.4　分时电价下的线性规划结果", "h2"),
        table_block("表 7　规则控制与优化调度的典型日成本比较", tou_table(), [18 * mm, 39 * mm, 39 * mm, 28 * mm, 22 * mm]),
    ]
    story += figure("05_tou_optimization.png", "图 6　园区 C 在规则控制与优化调度下的购电曲线")
    story += [
        p(f"优化器把有限电量优先保留给高电价时段。相较规则控制，A、B、C 分别节省 {tou_saving['A']:.2f}、{tou_saving['B']:.2f} 和 {tou_saving['C']:.2f} 元/典型日，且优化成本均不高于规则成本。RQ2 的答案是：分时电价为主动调度提供了额外价值，但改善幅度受可充电量、负荷缺额时段和电池规模共同限制。"),
        PageBreak(),
        p("5.5　分时电价下的全年容量搜索", "h2"),
        table_block("表 8　基准参数下的候选集最优配置", capacity_table(), [14 * mm, 20 * mm, 23 * mm, 34 * mm, 30 * mm, 37 * mm]),
    ]
    story += figure("06_capacity_search.png", "图 7　每个容量选取最优功率后的年成本变化，零线为无储能基准")
    story += [
        p(f"基准分时电价下，A 园区选择 {best['A']['power_kw']:.0f}/{best['A']['energy_kwh']:.0f} kW/kWh；B 园区选择 {best['B']['power_kw']:.0f}/{best['B']['energy_kwh']:.0f} kW/kWh；C 园区选择 {best['C']['power_kw']:.0f}/{best['C']['energy_kwh']:.0f} kW/kWh。A 园区不配置储能，说明其候选储能的边际运行收益低于年化投资。B、C 存在小规模经济配置，但容量继续增加后，新增投资超过新增运行节省。"),
        p("5.6　敏感性分析", "h2"), p("表中配置按“功率/容量（kW/kWh）”表示。", "small"),
        table_block("表 9　关键参数变化下的最优配置", sensitivity_table(), [16 * mm, 33 * mm, 34 * mm, 38 * mm, 32 * mm]),
    ]
    story += figure("08_sensitivity.png", "图 8　购电价格、储能成本和寿命变化下的最优容量")
    story += [
        p("A 园区在测试范围内始终不配置储能。B、C 的最优容量会随经济参数变化，低购电价、高投资或短寿命降低配置意愿；高购电价、低投资或长寿命则通常支持更大容量。因搜索集合离散，配置随参数可能跳变，不能将相邻情景的变化解释为连续最优解。完整双向扰动数据见 results.md。"),
        Spacer(1, 2 * mm),
        p("5.7　双目标 Pareto 配置结果", "h2"),
        table_block("表 10　不同决策偏好下的储能配置", multiobjective_table(), [13 * mm, 25 * mm, 22 * mm, 25 * mm, 42 * mm, 27 * mm]),
    ]
    story += figure("09_pareto_front.png", "图 9　年等效总成本与弃电率的 Pareto 前沿")
    story += [
        p(f"经济优先方案沿用单目标容量搜索结果。综合折中方案分别为 A 园区 {multi['A']['balanced']['power_kw']:.0f}/{multi['A']['balanced']['energy_kwh']:.0f}、B 园区 {multi['B']['balanced']['power_kw']:.0f}/{multi['B']['balanced']['energy_kwh']:.0f}、C 园区 {multi['C']['balanced']['power_kw']:.0f}/{multi['C']['balanced']['energy_kwh']:.0f} kW/kWh。相较各自经济优先方案，折中方案的年等效总成本仅增加约 {cost_increase['A']:.2f}%、{cost_increase['B']:.2f}% 和 {cost_increase['C']:.2f}%，弃电率却分别降低 {curtailment_drop['A']:.2f}、{curtailment_drop['B']:.2f} 和 {curtailment_drop['C']:.2f} 个百分点。消纳优先方案均为候选集合中的 150/300 kW/kWh，但其成本高于折中方案。RQ4 的答案是：Pareto 前沿能保留成本与消纳之间的有效取舍，理想点方法可以在不预先指定货币化环境收益的情况下给出可解释的折中建议。"),
        p("6　讨论", "h1"),
        p("6.1　技术效果与经济效果的边界", "h2"),
        p("结果中最容易混淆的两件事是“储能减少购电”和“储能值得投资”。前者由能量时移直接产生，属于技术指标；后者还取决于电价差、设备成本、寿命和利用频率。固定方案在三个园区均降低运行成本，却仍出现负的净年节省，正说明技术有效性不是经济可行性的充分条件。"),
        p("6.2　园区差异的形成机制", "h2"),
        p(f"A 园区光伏富余集中于白天，储能利用受每天单次充电机会限制，当前收益不足以回收候选投资。B 园区的弃风时段更分散，循环边界允许保留午夜前余电。C 园区兼有风光，充放电机会与价格的匹配不同于 B。循环规则策略下 {closest} 最接近盈亏平衡；分时电价下 B、C 的经济配置分别为 {best['B']['power_kw']:.0f}/{best['B']['energy_kwh']:.0f} 和 {best['C']['power_kw']:.0f}/{best['C']['energy_kwh']:.0f} kW/kWh。"),
        p("6.3　双目标创新的决策价值", "h2"),
        p(f"单目标方法会把 A 园区的不配置储能视为唯一答案，但 Pareto 分析表明，若园区愿意承担约 {cost_increase['A']:.2f}% 的额外年成本，{multi['A']['balanced']['power_kw']:.0f}/{multi['A']['balanced']['energy_kwh']:.0f} kW/kWh 能显著降低弃电率。B、C 的折中方案也以较小成本增量换取更高消纳率。该方法没有把环保收益强行折算为货币，而是保留成本和弃电率两个原始指标，使决策者能够根据园区考核目标选择方案。"),
        p("6.4　工程应用启示", "h2"),
        p("实际项目不应先给定储能容量再寻找收益，而应先获得可靠的逐时负荷、风光和电价数据，在多种价格与寿命情景下联合优化功率、容量和运行策略。若后续计入需量电费、辅助服务收益、可靠性价值或补贴，储能经济性可能改善；若计入衰减、维护和融资成本，经济性则可能下降。"),
        p("6.5　局限性与有效性威胁", "h2"),
        p("本文重复使用同一负荷曲线，不能体现季节性和工作日差异；循环代表日仅允许同类日间电量衔接，不能刻画真实连续低风低光天气和跨月储能。直线年化未计衰减、维护、残值与贴现。容量搜索仅保证候选集内最优，Pareto 筛选又限定于经济调度候选点。风光按比例分摊、禁止电网充电同样限制结论，不宜将结果直接用作工程可研。"),
        p("6.6　边界条件敏感性与失效原因", "h2"),
        table_block("表 11　仅改变日初边界时的候选集最优配置", [["园区", "日初日末均固定10%", "仅要求日初=日末"]] + [[park, f"{boundary[park]['fixed_minimum']['power_kw']:.0f}/{boundary[park]['fixed_minimum']['energy_kwh']:.0f}", f"{boundary[park]['cyclic']['power_kw']:.0f}/{boundary[park]['cyclic']['energy_kwh']:.0f}"] for park in "ABC"], [20*mm, 63*mm, 63*mm]),
        p("表 11 的单位为 kW/kWh。固定最低初值会排除午夜前后移峰，B 园区受影响尤为明显。因此正文统一采用自由初值的循环边界。另一类失效是每天重置规则策略电量：B 的 2、3、5 月和 C 的 3 月存在日末余电，若不衔接而直接乘天数，会低估储能运行节省。程序以稳态迭代和起点平移测试分别防止这两类边界错误。"),
        p("7　结论与展望", "h1"),
        p("本文的结论需要按实验条件区分。固定方案评价、经济容量搜索和 Pareto 折中决策回答的是三个不同问题，不能把对应配置直接相互比较。", "note"),
        p("7.1　固定电价下的固定方案评价", "h2"),
        p("在固定 1 元/kWh 购电价格和循环规则策略下，50 kW/100 kWh 储能减少三个园区的购电、弃电和运行成本，但运行节省不足以覆盖每年 2.2 万元投资摊销。此结论仅评价规则策略下的题设方案，不排除其他调度方法或经济参数改善其收益。"),
        p("7.2　分时电价下的经济优先配置", "h2"),
        p(f"在线性规划调度和基准经济参数下，A、B、C 的经济优先配置分别为 {best['A']['power_kw']:.0f}/{best['A']['energy_kwh']:.0f}、{best['B']['power_kw']:.0f}/{best['B']['energy_kwh']:.0f} 和 {best['C']['power_kw']:.0f}/{best['C']['energy_kwh']:.0f} kW/kWh。A 不配置储能最省钱；B、C 适合小规模储能。敏感性分析进一步表明，B、C 的具体配置会随购电价格、储能成本和寿命变化，因此必须同时报告参数条件。"),
        p("7.3　兼顾新能源消纳的综合折中配置", "h2"),
        p(f"若园区除成本外还重视降低弃电率，Pareto 理想点方法推荐 A、B、C 分别采用 {multi['A']['balanced']['power_kw']:.0f}/{multi['A']['balanced']['energy_kwh']:.0f}、{multi['B']['balanced']['power_kw']:.0f}/{multi['B']['balanced']['energy_kwh']:.0f} 和 {multi['C']['balanced']['power_kw']:.0f}/{multi['C']['balanced']['energy_kwh']:.0f} kW/kWh。相较经济优先方案，三者年等效总成本仅增加约 {cost_increase['A']:.2f}%、{cost_increase['B']:.2f}% 和 {cost_increase['C']:.2f}%，弃电率分别下降 {curtailment_drop['A']:.2f}、{curtailment_drop['B']:.2f} 和 {curtailment_drop['C']:.2f} 个百分点。这些配置不是新的经济最优解，而是园区愿意以少量成本换取更多新能源消纳时的折中选择。"),
        p("7.4　结论边界与展望", "h2"),
        p("以上三组结论并不矛盾：第一组评价题目给定方案是否值得投资，第二组寻找分时电价下的最低成本配置，第三组讨论成本与弃电率之间的取舍。后续研究可引入全年逐时负荷与气象数据、电池循环衰减、贴现现金流和需量电费，并采用连续容量变量或混合整数规划，提高结论的工程可信度。"),
        p("参考文献", "h1"),
        p("[1] aaziqi. DianGongBei_A: 2024 电工杯 A 题数据附件[EB/OL]. GitHub, 2024. https://github.com/aaziqi/DianGongBei_A（访问日期：2026-09-14）.", "reference"),
        p("[2] Chen S X, Gooi H B, Wang M Q. Sizing of energy storage for microgrids[J]. IEEE Transactions on Smart Grid, 2012, 3(1): 142-151. DOI: 10.1109/TSG.2011.2160745.", "reference"),
        p("[3] Yang Y, Bremner S, Menictas C, et al. Battery energy storage system size determination in renewable energy systems: A review[J]. Renewable and Sustainable Energy Reviews, 2018, 91: 109-125. DOI: 10.1016/j.rser.2018.03.047.", "reference"),
    ]

    doc.build(story, onFirstPage=footer, onLaterPages=footer)
    print(f"论文版报告已生成：{OUT}")


if __name__ == "__main__":
    build()
