"""独立累计能量建模与边界回归测试。运行：python code/test_analysis.py。"""
import sys
sys.dont_write_bytecode = True
import unittest
import numpy as np
import pandas as pd
from scipy.optimize import linprog
import analysis as a


def cumulative_lp(df, power, energy, prices):
    """独立模型：消去逐时能量变量，只保留充放电和可变日初电量。"""
    pv, wind, load = [df[k].to_numpy(float) for k in ("pv", "wind", "load")]
    n = len(df)
    surplus, deficit = np.maximum(pv+wind-load, 0), np.maximum(load-pv-wind, 0)
    cost = np.divide(.4*pv+.5*wind, pv+wind, out=np.zeros(n), where=pv+wind>0)
    cumulative = np.c_[.95*np.tril(np.ones((n,n))), -np.tril(np.ones((n,n)))/.95, np.ones(n)]
    cycle = np.r_[np.full(n,.95),np.full(n,-1/.95),0][None,:]
    solution = linprog(np.r_[cost,-prices,0], A_ub=np.r_[cumulative,-cumulative],
        b_ub=np.r_[np.full(n,.9*energy),np.full(n,-.1*energy)], A_eq=cycle,b_eq=[0],
        bounds=[(0,min(power,v)) for v in surplus]+[(0,min(power,v)) for v in deficit]+[(.1*energy,.9*energy)],method="highs")
    if not solution.success:
        raise AssertionError(solution.message)
    return float(solution.fun + np.dot(deficit,prices) + np.dot(np.minimum(pv+wind,load),cost))


class ModelTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.typical=a.load_typical_day()
        cls.monthly=a.load_monthly_generation(cls.typical)

    def test_all_days_and_prices(self):
        result=a.validate_dataset(self.typical,self.monthly)
        self.assertEqual(result["dispatch_checks"],156)
        self.assertLess(result["max_cycle_gap_kwh"],1e-6)

    def test_independent_lp(self):
        cases=list(self.typical.values())+[df for parks in self.monthly.values() for df in parks.values()]
        for df in cases:
            for prices in (np.ones(24),a.tou_prices()):
                result=a.optimal_storage(df,50,100,prices)
                self.assertAlmostEqual(result["metrics"]["total_cost_yuan"],cumulative_lp(df,50,100,prices),places=5)

    def test_rotation_does_not_create_midnight_penalty(self):
        for park in "ABC":
            df=self.monthly[3][park]
            prices=a.tou_prices()
            expected=a.optimal_storage(df,50,100,prices)["metrics"]["total_cost_yuan"]
            shifted=pd.concat([df.iloc[7:],df.iloc[:7]],ignore_index=True)
            actual=a.optimal_storage(shifted,50,100,np.roll(prices,-7))["metrics"]["total_cost_yuan"]
            self.assertAlmostEqual(actual,expected,places=5)

    def test_edge_cases(self):
        for load,pv in ((0,0),(10,0),(0,20),(10,10)):
            df=pd.DataFrame({"load":[load]*24,"pv":[pv]*24,"wind":[0.]*24})
            for p,e in ((0,0),(50,100)):
                for strategy in (a.greedy_storage,a.optimal_storage):
                    r=strategy(df,p,e,np.ones(24))
                    a.validate_dispatch(df,r,p,e)
                    self.assertAlmostEqual(r["metrics"]["total_cost_yuan"],a.baseline(df)["metrics"]["total_cost_yuan"],places=5)
                    if load==0:
                        self.assertIsNone(a.rounded_metrics(r["metrics"])["unit_cost_yuan_per_kwh"])
        with self.assertRaises(ValueError):
            a.greedy_storage(self.typical["A"],-1,100)

    def test_previous_overnight_failures(self):
        for park,month in (("B",2),("B",3),("B",5),("C",3)):
            r=a.greedy_storage(self.monthly[month][park],50,100)
            self.assertAlmostEqual(r["soc"][0],r["soc"][-1],places=6)

    def test_annual_cost_and_capacity(self):
        net={"A":-11513.618421052583,"B":-1191.1207236840855,"C":-1275.995074232109}
        expected={"A":(0,0),"B":(100,200),"C":(50,100)}
        for park in "ABC":
            self.assertAlmostEqual(a.fixed_storage_economics(self.monthly,park)["net_annual_saving_yuan"],net[park],places=4)
            best,candidates=a.search_capacity(self.monthly,park)
            self.assertEqual(len(candidates),26)
            self.assertEqual((best["power_kw"],best["energy_kwh"]),expected[park])
            self.assertAlmostEqual(best["unit_cost_yuan_per_kwh"],best["total_cost_yuan"]/best["load_kwh"],places=10)
            for row in candidates:
                independent=sum(cumulative_lp(self.monthly[m][park],row["power_kw"],row["energy_kwh"],a.tou_prices())*a.monthrange(2026,m)[1] for m in range(1,13))
                self.assertAlmostEqual(row["total_cost_yuan"],independent,places=4)

    def test_existing_self_checks(self):
        a.self_check()


if __name__=="__main__":
    unittest.main(verbosity=2)
